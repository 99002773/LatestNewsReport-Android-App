News App

Features
- Login
- Retrofit
- News Api feeding
- SQL Lite
- language
- 
